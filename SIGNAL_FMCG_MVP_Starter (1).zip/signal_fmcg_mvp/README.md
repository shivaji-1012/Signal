# SIGNAL — FMCG Financial Research MVP

A caselet-guided financial research prototype for ATMOS 2026 Track C.

## What this MVP does
- Provides a Streamlit dashboard for investigating a public FMCG company.
- Includes 18 structured caselets across six families.
- Uses Gemini with Google Search grounding in a three-stage workflow:
  1. Discover company narrative and candidate discrepancies.
  2. Test competing hypotheses using caselets and additional sources.
  3. Search for counterarguments and produce a falsifiable research report.
- Displays the report, grounding source links, intermediate stages, and caselet library.
- Includes a clearly labelled demo mode that does not make real company claims.

## What it does not yet guarantee
- It does not guarantee that every cited source supports every claim.
- It does not yet extract all financial tables into a validated structured database.
- It does not guarantee a discovery for every company.
- The report must be manually checked against primary sources before presenting it as fact.
- This is a planning-stage starter MVP; it is not evidence that the system has already passed evaluation.

## 1. Platforms/accounts
1. Python 3.11 or 3.12
2. VS Code (or another Python editor)
3. Google AI Studio to obtain a Gemini API key
4. GitHub to store the project
5. Streamlit Community Cloud to deploy a shareable dashboard

Official docs:
- Gemini Google Search grounding: https://ai.google.dev/gemini-api/docs/google-search/
- Streamlit secrets: https://docs.streamlit.io/develop/concepts/connections/secrets-management
- Streamlit deploy: https://docs.streamlit.io/deploy/streamlit-community-cloud/deploy-your-app

## 2. Run locally (Windows)
1. Extract the ZIP.
2. Open the extracted `signal_fmcg_mvp` folder in VS Code.
3. Open Terminal > New Terminal.
4. Create a virtual environment:
   ```powershell
   py -m venv .venv
   .venv\Scripts\activate
   ```
5. Install dependencies:
   ```powershell
   pip install -r requirements.txt
   ```
6. Create `.streamlit/secrets.toml` by copying `.streamlit/secrets.toml.example`.
7. Add your key inside the file:
   ```toml
   GEMINI_API_KEY = "paste_your_key_here"
   ```
8. Start the app:
   ```powershell
   streamlit run app.py
   ```
9. Open the local URL shown in the terminal (usually `http://localhost:8501`).

Do not share your API key or commit `secrets.toml` to GitHub.

## 3. Test in this order
1. Choose **Demo interface** first to confirm the UI works. Demo output is synthetic and not company research.
2. Switch to **Live research** and use HUL as the first test.
3. Check every important figure against the original filing.
4. Try ITC or Nestlé India.
5. Try a company not used in your first examples to test generalisation.
6. Record failures: missing sources, incorrect numbers, weak counterarguments, and unsupported conclusions.

## 4. Project structure
```text
signal_fmcg_mvp/
├── app.py
├── caselets.json
├── requirements.txt
├── .gitignore
├── README.md
└── .streamlit/
    └── secrets.toml.example
```

## 5. Deploy on Streamlit Community Cloud
1. Create a GitHub repository and upload the project files.
2. Make sure `.streamlit/secrets.toml` is not uploaded; the `.gitignore` excludes it.
3. Sign in at https://share.streamlit.io/ and create an app from your repository.
4. Select `app.py` as the entrypoint.
5. In the app's Advanced settings / Secrets area, add:
   ```toml
   GEMINI_API_KEY = "paste_your_key_here"
   ```
6. Deploy and test the live URL.

API model availability, Google Search grounding access, usage limits and billing/quotas depend on your Google AI account and current API terms. Verify these before a live demo.
