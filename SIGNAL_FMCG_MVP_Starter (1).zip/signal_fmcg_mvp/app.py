import os
import json
import re
from datetime import datetime

import streamlit as st
import pandas as pd
from google import genai
from google.genai import types

APP_NAME = "SIGNAL"
CASELET_PATH = os.path.join(os.path.dirname(__file__), "caselets.json")

st.set_page_config(
    page_title="SIGNAL | FMCG Financial Research",
    page_icon="◈",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown("""
<style>
:root { --navy:#102238; --blue:#2C5F8A; --teal:#2A827A; }
.block-container {padding-top: 1.6rem; padding-bottom: 3rem; max-width: 1400px;}
.hero {padding: 1.2rem 1.4rem; border-radius: 16px;
       background: linear-gradient(120deg,#102238,#1E4160);
       color: white; margin-bottom: 1rem; border: 1px solid #294b68;}
.hero h1 {font-size: 2.1rem; margin: 0 0 .25rem 0; color: white;}
.hero p {margin: 0; color: #dce8f2; font-size: 1rem;}
.eyebrow {text-transform:uppercase; letter-spacing:.16em; font-size:.72rem; color:#8dc9c4; font-weight:700;}
.small-note {color:#617185; font-size:.85rem;}
.source-card {border:1px solid #dce4ec; padding:.75rem; border-radius:10px; margin-bottom:.5rem;}
div[data-testid="stMetric"] {border:1px solid #dce4ec; border-radius:12px; padding:.8rem;}
</style>
""", unsafe_allow_html=True)

def load_caselets():
    with open(CASELET_PATH, "r", encoding="utf-8") as f:
        return json.load(f)

CASELETS = load_caselets()

def get_api_key():
    key = os.getenv("GEMINI_API_KEY", "")
    try:
        key = key or st.secrets.get("GEMINI_API_KEY", "")
    except Exception:
        pass
    return key

def extract_grounding_sources(response):
    found = []
    try:
        for candidate in (getattr(response, "candidates", None) or []):
            meta = getattr(candidate, "grounding_metadata", None)
            chunks = getattr(meta, "grounding_chunks", None) if meta else None
            for chunk in (chunks or []):
                web = getattr(chunk, "web", None)
                if web:
                    url = getattr(web, "uri", None)
                    title = getattr(web, "title", None) or url
                    if url and not any(s["url"] == url for s in found):
                        found.append({"title": title, "url": url})
    except Exception:
        pass
    return found

def grounded_call(client, model, prompt):
    response = client.models.generate_content(
        model=model,
        contents=prompt,
        config=types.GenerateContentConfig(
            tools=[types.Tool(google_search=types.GoogleSearch())],
            temperature=0.2,
        ),
    )
    return (getattr(response, "text", None) or "No text returned by the model."), extract_grounding_sources(response)

def compact_caselets(caselets, selected_families=None):
    selected = [c for c in caselets if not selected_families or c["family"] in selected_families]
    return json.dumps([
        {k:c[k] for k in ["id","family","title","trigger","blind_spot","data_needed","checks","alternatives","falsification"]}
        for c in selected
    ], ensure_ascii=False)

def run_investigation(company, period, focus, caselet_text, client, model, progress):
    sources = []
    progress.update(label="Stage 1/3 · Discovering the company's public narrative", state="running")
    p1 = f"""
You are SIGNAL, an evidence-first FMCG financial research investigator.
Company: {company}
Period to investigate: {period}
Research focus: {focus or "Find the strongest evidence-supported non-obvious financial discrepancy."}

Use Google Search grounding to research the company. Prioritise primary sources: official investor relations pages, annual reports,
quarterly results, exchange filings and presentations. Use credible peer/industry sources for context.
Identify the company's relevant claims or stated growth drivers, the most important reported financial trends, and possible discrepancies
worth testing. Do not invent numbers. Distinguish reported facts, management claims and your own hypotheses. If you cannot verify a fact, say so.
Return a concise research brief with dated facts, candidate hypotheses, and the URLs/sources you relied on.
"""
    stage1, src1 = grounded_call(client, model, p1)
    sources += src1
    progress.update(label="Stage 2/3 · Testing hypotheses using caselets and financial relationships", state="running")
    p2 = f"""
You are the second-stage analyst in SIGNAL. Research target: {company}. Period: {period}. Focus: {focus or "best-supported discrepancy"}.

FIRST-STAGE RESEARCH BRIEF:
{stage1}

REUSABLE CASELET LIBRARY (investigation patterns, not answers):
{caselet_text}

Using Google Search grounding, investigate the most promising 2–4 hypotheses. For each:
- state the hypothesis and why it is non-obvious;
- specify the evidence that would support or weaken it;
- retrieve additional sources, prioritising original company disclosures and relevant competitors;
- report exact figures only when supported by a source, with units, periods and whether reported or calculated;
- calculate only relationships for which adequate comparable data exists;
- distinguish missing data from zero and avoid inferring undisclosed volume, channel or price contributions;
- note whether evidence is company-specific or may reflect the whole industry.
Do not force a contradiction. Return a compact evidence table and the strongest candidate discovery.
"""
    stage2, src2 = grounded_call(client, model, p2)
    sources += src2
    progress.update(label="Stage 3/3 · Seeking counterarguments and writing the discovery", state="running")
    p3 = f"""
You are SIGNAL's independent challenge stage. Your task is to test, not merely confirm, the leading hypothesis.

COMPANY: {company}
PERIOD: {period}
FOCUS: {focus or "best-supported discrepancy"}

STAGE 1 RESEARCH:
{stage1}

STAGE 2 HYPOTHESES AND EVIDENCE:
{stage2}

CASELET PLAYBOOK:
{caselet_text}

Use Google Search grounding to actively search for the strongest contradictory evidence, plausible alternative explanations, peer/industry evidence,
period-comparability problems and primary-source corrections. Do not treat correlation as causation. If evidence is too weak, say that the finding is inconclusive.

Produce the final report using these exact headings:
# Discovery
# Why It Matters
# Evidence and Calculations
# Timeline
# Strongest Counterargument
# Falsification Condition
# Evidence Strength
# Limitations and Missing Data

For each key claim, include source links and publication/reporting dates when available. Make clear which values are reported and which are calculated.
Do not provide an investment recommendation. Do not invent citations or claim a source supports something it does not.
"""
    final, src3 = grounded_call(client, model, p3)
    sources += src3
    dedup = []
    seen = set()
    for s in sources:
        if s["url"] not in seen:
            seen.add(s["url"])
            dedup.append(s)
    progress.update(label="Investigation complete", state="complete")
    return {"stage1": stage1, "stage2": stage2, "final": final, "sources": dedup, "run_at": datetime.now().strftime("%d %b %Y, %H:%M")}

def show_sources(sources):
    if not sources:
        st.info("No structured source links were returned in grounding metadata. Check the report text and rerun if key claims lack direct links.")
        return
    for i, source in enumerate(sources, 1):
        st.markdown(f"{i}. [{source['title']}]({source['url']})")

def sample_report(company):
    return f"""# Discovery
**Demo-only illustrative finding for {company}:** revenue growth may not fully represent underlying volume growth if pricing and product mix are not separated.

**This is synthetic demo text, not a researched claim about {company}.** No real company data was checked in demo mode.

# Why It Matters
- Revenue growth alone cannot establish volume-led demand.
- Pricing, mix, acquisitions and category growth can change the interpretation.
- The hypothesis must be tested with comparable-period disclosures.

# Evidence and Calculations
No real evidence or calculations are included in this demo. In live mode, the agent must cite original disclosures and label reported versus calculated values.

# Timeline
Demo placeholder: populate only after checking dated company sources.

# Strongest Counterargument
Volume growth may be broad-based, or the apparent gap may result from mix, scope or metric-definition differences.

# Falsification Condition
Reconsider the hypothesis if comparable disclosures show sustained volume-led growth and the apparent discrepancy is explained.

# Evidence Strength
Weak / illustrative only. This demo is not a company finding.

# Limitations and Missing Data
This screen demonstrates the interface only. Select Live research and provide a Gemini API key to run grounded research.
"""

st.markdown("""
<div class="hero">
  <div class="eyebrow">Autonomous financial research · Track C</div>
  <h1>◈ SIGNAL</h1>
  <p>Find the story behind the numbers. Test the narrative. Challenge the conclusion.</p>
</div>
""", unsafe_allow_html=True)

with st.sidebar:
    st.markdown("## Investigation setup")
    company = st.text_input("Company", value="Hindustan Unilever Limited", help="Try HUL, ITC, Nestlé India, or another eligible FMCG company.")
    period = st.selectbox("Research period", ["Latest available results + last 8 quarters", "Last 5 financial years", "Custom / most recent event"])
    focus = st.selectbox("Investigation focus", [
        "Discover the strongest non-obvious insight",
        "Revenue quality: price vs volume vs mix",
        "Profitability and margin divergence",
        "Cash conversion and working capital",
        "Distribution and channel economics",
        "Segment mix and company narrative",
    ])
    selected_families = st.multiselect(
        "Caselet families",
        sorted(set(c["family"] for c in CASELETS)),
        default=sorted(set(c["family"] for c in CASELETS)),
    )
    mode = st.radio("Mode", ["Live research", "Demo interface"], index=0)
    model = st.text_input("Gemini model", value=os.getenv("GEMINI_MODEL", "gemini-2.5-flash"))
    st.caption("Live mode uses Gemini API with Google Search grounding. API usage and availability depend on your Google AI account.")
    run_btn = st.button("▶ Run Investigation", type="primary", use_container_width=True)
    st.divider()
    st.caption("Evidence-first prototype · No investment recommendations")

col1, col2, col3 = st.columns(3)
col1.metric("Reasoning playbook", f"{len(CASELETS)} caselets")
col2.metric("Caselet families", len(set(c["family"] for c in CASELETS)))
col3.metric("Research stages", "3")

st.markdown("### Investigation workspace")
st.markdown("A discovery is not accepted merely because it sounds plausible. The agent must retrieve evidence, compare explanations and search for counterevidence.")

if run_btn:
    if not company.strip():
        st.error("Enter a company name first.")
    elif mode == "Demo interface":
        st.session_state["result"] = {
            "stage1": "DEMO ONLY — no web research was performed.",
            "stage2": "DEMO ONLY — no calculations or company claims were verified.",
            "final": sample_report(company.strip()),
            "sources": [],
            "run_at": datetime.now().strftime("%d %b %Y, %H:%M"),
        }
        st.session_state["demo"] = True
    else:
        key = get_api_key()
        if not key:
            st.error("Gemini API key not found. Add GEMINI_API_KEY to .streamlit/secrets.toml or choose Demo interface.")
        else:
            try:
                client = genai.Client(api_key=key)
                selected_text = compact_caselets(CASELETS, selected_families)
                with st.status("Preparing autonomous investigation...", expanded=True) as status:
                    progress = status
                    result = run_investigation(company.strip(), period, focus, selected_text, client, model, progress)
                    status.update(label="Investigation finished", state="complete", expanded=False)
                st.session_state["result"] = result
                st.session_state["demo"] = False
            except Exception as exc:
                st.error(f"The live investigation failed: {exc}")
                st.info("Check your API key, model access, network connection and Google Search grounding availability. No finding has been generated.")

result = st.session_state.get("result")
if result:
    if st.session_state.get("demo"):
        st.warning("DEMO INTERFACE ONLY — the displayed company example is synthetic and is not a researched finding.")
    st.caption(f"Last run: {result.get('run_at','—')} · Company: {company}")
    tabs = st.tabs(["Discovery report", "Evidence sources", "Investigation stages", "Caselet library"])
    with tabs[0]:
        st.markdown(result["final"])
        st.download_button(
            "Download report as Markdown",
            data=result["final"],
            file_name=f"signal_{re.sub(r'[^A-Za-z0-9]+','_',company.strip()).strip('_').lower() or 'company'}.md",
            mime="text/markdown",
        )
    with tabs[1]:
        st.markdown("#### Sources surfaced by search grounding")
        show_sources(result.get("sources", []))
        st.caption("Always open the original source and verify that it supports the specific claim before presenting the finding.")
    with tabs[2]:
        with st.expander("Stage 1 · Initial research brief", expanded=False):
            st.markdown(result.get("stage1", "Not available"))
        with st.expander("Stage 2 · Hypothesis testing", expanded=False):
            st.markdown(result.get("stage2", "Not available"))
        with st.expander("Stage 3 · Self-falsification and final report", expanded=True):
            st.markdown(result.get("final", "Not available"))
    with tabs[3]:
        st.markdown("#### Caselets used in this prototype")
        family_filter = st.selectbox("Filter by family", ["All"] + sorted(set(c["family"] for c in CASELETS)), key="library_filter")
        for caselet in CASELETS:
            if family_filter != "All" and caselet["family"] != family_filter:
                continue
            with st.expander(f"{caselet['id']} · {caselet['title']}"):
                st.markdown(f"**Family:** {caselet['family']}")
                st.markdown(f"**Trigger:** {caselet['trigger']}")
                st.markdown(f"**Blind spot:** {caselet['blind_spot']}")
                st.markdown("**Data needed:** " + "; ".join(caselet["data_needed"]))
                st.markdown("**Checks:** " + "; ".join(caselet["checks"]))
                st.markdown("**Alternative explanations:** " + "; ".join(caselet["alternatives"]))
                st.markdown(f"**Falsification:** {caselet['falsification']}")
else:
    left, right = st.columns([1.15, 0.85])
    with left:
        st.markdown("#### How the investigation runs")
        st.markdown("""
        1. **Discover:** search for company disclosures, claims and financial trends.
        2. **Test:** retrieve relevant caselets and compare competing hypotheses.
        3. **Challenge:** search for counterevidence, alternative explanations and data limitations.
        """)
        st.info("Choose Live research to run the three-stage Gemini workflow, or Demo interface to inspect the UI without making API calls.")
    with right:
        st.markdown("#### Output checklist")
        for item in ["One-sentence discovery", "Why it matters", "Evidence and calculations", "Timeline", "Strongest counterargument", "Falsification condition", "Evidence strength and limitations"]:
            st.markdown(f"- {item}")
        st.markdown("#### Design principle")
        st.caption("Caselets guide the investigation; they do not prescribe the answer.")

st.divider()
st.caption("SIGNAL MVP · Proposed prototype · Research assistance only, not investment advice.")
